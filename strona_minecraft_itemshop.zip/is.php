﻿<?php
/*
╒═══════════════════════════════════════════════╕
  SMS Shop by exevan/goukan pod DotPay.pl SMS 
╘═══════════════════════════════════════════════╛
╒════════════╕
 KONFIGURACJA
╘════════════╛
Aby dzialalo polaczenie Rcon nalezy dodac do server.properties takie linijki:
enable-rcon=true
rcon.port=25575
rcon.password=haslo
*/
//Polaczenie RCon
define( 'MQ_SERVER_ADDR', 'mycrafts.pl' ); //ip serwera minecraft
define( 'MQ_SERVER_PORT', 25575 ); //RCon port serwera minecraft 
define( 'MQ_SERVER_PASS', 'supermocnehaslo'); //haslo rcon serwera minecraft
define( 'MQ_TIMEOUT', 2 );

//Powiadomienia mail
$dane = "SMS Shop"; //Dostajac meila ten napis bedzie widnial w rubryce 'Od kogo?'
$headers1='MIME-Version: 1.0'."\n"; //nie ruszaj!
$headers1.='Content-type: text/html; charset=UTF-8'."\n"; //nie ruszaj!
$headers1.='from: <'.$dane.">\n"; //nie ruszaj!
$data=date("Y-m-d H:i"); // nie ruszaj!
$email = "email";  // twoj email
$czy_email = "tak"; // Chcesz otrzymywac powiadomienia email o zakupionych uslugach? Wpisz tak lub nie.

//Dane do usług sms
$shop['id'] = 61572; //ID klienta dotpay
$del = 1;
$type = "sms"; # typ konta: C1 - 8 znakowy kod bezobsługowy ; sms - kody sms

//Dane do strony
$current = "?page_id=4"; //strona glowna sms shopa np. ?page_id=4 lub sms.php
$wlasciciel = "NazwaStrony.pl"; //nazwa wlasciciela strony
$oprogramowanie = "wp"; // wpisz na jakim oprogramowaniu bedzie dzialac sms shop: wp, inne
$offer = array(array()); // nie ruszaj!

//Uslugi SMS Shop
$offer[1]['offer_type'] = "item"; //nie ruszac
$offer[1]['image'] = "http://files.softicons.com/download/system-icons/omnom-icons-by-ampeross/ico/minecraft.ico";
$offer[1]['item_name'] = "VIP (45 dni)";
$offer[1]['opis'] = "
<b>Co może VIP?</b>
<br>
-Komenda /fly<br>
-Bzykać dziewczyny<br>
-Palić marihuaen xD<br>
-Używać GameMode
";
$offer[1]['number'] = 7655; //numer na ktory trzeba wyslac sms
$offer[1]['code'] = "ENR12"; //tresc smsa(bez AP.)
$offer[1]['price'] = "7,32"; //koszt smsa
$offer[1]['komenda1'] = "say [nick] dupa [nick]";  //[nick] - nick gracza, jesli nie chcesz tylu komend w danej usludze to zostaw puste
$offer[1]['komenda2'] = "say kuuurwa [nick]";
$offer[1]['komenda3'] = "";
$offer[1]['komenda4'] = "";
$offer[1]['komenda5'] = "";
$offer[1]['komenda6'] = "";
$offer[1]['komenda7'] = "";

$offer[2]['offer_type'] = "item"; //nie ruszac
$offer[2]['image'] = "http://files.softicons.com/download/system-icons/omnom-icons-by-ampeross/ico/minecraft.ico"; //sciezka do obrazka uslugi
$offer[2]['item_name'] = "UNBAN";
$offer[2]['number'] = 7655; //numer na ktory trzeba wyslac sms
$offer[2]['code'] = "ENR36"; //tresc smsa(bez AP.)
$offer[2]['price'] = "7,32"; //koszt smsa
$offer[2]['komenda1'] = "time day";  //[nick] - nick gracza, jesli nie chcesz tylu komend w danej usludze to zostaw puste
$offer[2]['komenda2'] = "say [nick] to jest drugie gowno";
$offer[2]['komenda3'] = "";
$offer[2]['komenda4'] = "";
$offer[2]['komenda5'] = "";
$offer[2]['komenda6'] = "";
$offer[2]['komenda7'] = "";

$offer[3]['offer_type'] = "item"; //nie ruszac
$offer[3]['image'] = "http://files.softicons.com/download/system-icons/omnom-icons-by-ampeross/ico/minecraft.ico";
$offer[3]['item_name'] = "COS TAM";
$offer[3]['number'] = 7655; //numer na ktory trzeba wyslac sms
$offer[3]['code'] = "ENR36"; //tresc smsa(bez AP.)
$offer[3]['price'] = "7,32"; //koszt smsa
$offer[3]['komenda1'] = "";  //[nick] - nick gracza, jesli nie chcesz tylu komend w danej usludze to zostaw puste
$offer[3]['komenda2'] = "";
$offer[3]['komenda3'] = "";
$offer[3]['komenda4'] = "";
$offer[3]['komenda5'] = "";
$offer[3]['komenda6'] = "";
$offer[3]['komenda7'] = "";

/*
╒════════════════════════╕
	KONIEC KONFIGURACJI
╘════════════════════════╛
*/
?>
<!-- NIE RUSZAC TEGO NIZEJ-->
<?php
class MinecraftRconException extends Exception
{
	// Exception thrown by MinecraftRcon class
}
class MinecraftRcon
{
	// Sending
	const SERVERDATA_EXECCOMMAND    = 2;
	const SERVERDATA_AUTH           = 3;
	// Receiving
	const SERVERDATA_RESPONSE_VALUE = 0;
	const SERVERDATA_AUTH_RESPONSE  = 2;
	private $Socket;
	private $RequestId;
	public function __destruct( )
	{
		$this->Disconnect( );
	}
	public function Connect( $Ip, $Port = 25575, $Password, $Timeout = 3 )
	{
		$this->RequestId = 0;
		if( $this->Socket = FSockOpen( $Ip, (int)$Port ) )
		{
			Socket_Set_TimeOut( $this->Socket, $Timeout );
			if( !$this->Auth( $Password ) )
			{
				$this->Disconnect( );
				throw new MinecraftRconException( "Authorization failed." );
			}
		}
		else
		{
			throw new MinecraftRconException( "Can't open socket." );
		}
	}
	public function Disconnect( )
	{
		if( $this->Socket )
		{
			FClose( $this->Socket );
			
			$this->Socket = null;
		}
	}
	public function Command( $String )
	{
		if( !$this->WriteData( self :: SERVERDATA_EXECCOMMAND, $String ) )
		{
			return false;
		}
		$Data = $this->ReadData( );
		if( $Data[ 'RequestId' ] < 1 || $Data[ 'Response' ] != self :: SERVERDATA_RESPONSE_VALUE )
		{
			return false;
		}

		return $Data[ 'String' ];
	}
	private function Auth( $Password )
	{
		if( !$this->WriteData( self :: SERVERDATA_AUTH, $Password ) )
		{
			return false;
		}
		$Data = $this->ReadData( );
		return $Data[ 'RequestId' ] > -1 && $Data[ 'Response' ] == self :: SERVERDATA_AUTH_RESPONSE;
	}
	private function ReadData( )
	{
		$Packet = Array( );
		$Size = FRead( $this->Socket, 4 );
		$Size = UnPack( 'V1Size', $Size );
		$Size = $Size[ 'Size' ];
		// TODO: Add multiple packets (Source)
		$Packet = FRead( $this->Socket, $Size );
		$Packet = UnPack( 'V1RequestId/V1Response/a*String/a*String2', $Packet );
		return $Packet;
	}
	private function WriteData( $Command, $String = "" )
	{
		// Pack the packet together
		$Data = Pack( 'VV', $this->RequestId++, $Command ) . $String . "\x00\x00\x00"; 
		// Prepend packet length
		$Data = Pack( 'V', StrLen( $Data ) ) . $Data;
		$Length = StrLen( $Data );
		return $Length === FWrite( $this->Socket, $Data, $Length );
	}
}
if($oprogramowanie == "wp") $zn="&";
else $zn="?";
?>
<!-- NIE RUSZAC TEGO WYZEJ-->
<?php
$erno = 0;
if($_POST['offer'] == "item") 
{
	echo'<div style="width: 500px; padding: 15px; border:1px solid #ababab; margin: 0px auto;">';
    $nick = $_POST['nick'];
    $check = $_POST['check'];
	$offerId = $_POST['numer'];
	//nie ruszaj
	$offer[$offerId]['komenda1'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda1']);
	$offer[$offerId]['komenda2'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda2']);
	$offer[$offerId]['komenda3'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda3']);
	$offer[$offerId]['komenda4'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda4']);  
	$offer[$offerId]['komenda5'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda5']);  
	$offer[$offerId]['komenda6'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda6']);  
	$offer[$offerId]['komenda7'] = str_replace("[nick]", $nick, $offer[$offerId]['komenda7']);  	
	$wiadomosc=" 
<html>
	<body>
		W twoim SMS Shopie została kupiona usługa z danymi:<br>
		Nick: $nick<br />
		Nazwa usługi: ".$offer[$offerId]['item_name']."<br />
		Data: $data<br>
		Kod do tej usługi: $check<br>
		Komendy jakie zostały wpisane:<br>
		1. ".$offer[$offerId]['komenda1']."<br>
		2. ".$offer[$offerId]['komenda2']."<br>
		3. ".$offer[$offerId]['komenda3']."<br>
		4. ".$offer[$offerId]['komenda4']."<br>
		5. ".$offer[$offerId]['komenda5']."<br>
		6. ".$offer[$offerId]['komenda6']."<br>
		7. ".$offer[$offerId]['komenda7']."<br>

		<br />
	</body>
</html>"; //wiadomosc jaka sie pojawi w email

//Sprawdzacz kodu
	$handle = fopen("http://dotpay.pl/check_code.php?&check=".$check."&id=".$shop['id']."&code=".$offer[$offerId]['code']."&type=".$type."&del=".$del, 'r');
    $status = fgets($handle, 8);
    fclose($handle);

	if(empty($check) || empty($nick))
	{
		$message = "Wypełnij wszystkie pola.";
	}
    else if($status == 0 || preg_match('/[^0-9A-Za-z]/', $check) )
	{
		$message = "Nieprawidlowy kod.";
	}
    else if($status == 1)
    {	
	    $message = '<img src="http://upload.wikimedia.org/wikipedia/commons/4/47/Done.png" style="max-width:100px; max-height:100px;"><br>
		Kod został wprowadzony poprawnie. '.$offer[$offerId]['item_name'].' został dodany na postać '.$nick.'.';
		if($czy_email=="tak") mail($email, $nick.' kupił usługę', $wiadomosc, $headers1);	
		else echo '';
		$Rcon = new MinecraftRcon;
		$Rcon->Connect( MQ_SERVER_ADDR, MQ_SERVER_PORT, MQ_SERVER_PASS, MQ_TIMEOUT );		
		$Data = $Rcon->Command($offer[$offerId]['komenda1']);		
		$Data = $Rcon->Command($offer[$offerId]['komenda2']);	
		$Data = $Rcon->Command($offer[$offerId]['komenda3']);	
		$Data = $Rcon->Command($offer[$offerId]['komenda4']);	
		$Data = $Rcon->Command($offer[$offerId]['komenda5']);	
		$Data = $Rcon->Command($offer[$offerId]['komenda6']);	
		$Data = $Rcon->Command($offer[$offerId]['komenda7']);			
		$Rcon->Disconnect();
    }
    else
	{
		$message = "Błąd w połączeniu z operatorem.";
	}
	
	if( isset($message) )
	{
		echo '<center>'.$message.'<br><a href="'.$current.$zn.'buy=item'.$offerId.'">Wróć do poprzedniej strony.</a></center>';
		$erno = 1;
	}	
	echo'</div>';
}
?>
<?php
if($_GET['buy'] != "" && $erno==0)
{
	$from = "0";
	$to = count($offer);
	while($from < $to)
	{	
		$from++;
		if($_GET['buy'] == "item".$from)
		{
		?>
		<!--↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓kawałek kodu odpowiedzialny za wyświetlanie tabelki z danymi do wyslania smsa i formularzem↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ -->
			<div id="test" style="width: 500px; height:550px; padding: 15px; border:1px solid #ababab; margin: 0px auto;">
				<form action="" method="post">
					<img src="<?php echo $offer[$from]['image']; ?>" style="max-width:165px; max-height:200px;"/><div style="float:right;">Koszt: <?php echo $offer[$from]['price']; ?> PLN</div>
					<center>
						Aby zakupić <?php echo $offer[$from]['item_name']; ?> wyślij sms o treści: <b>AP.<?php echo $offer[$from]['code']; ?></b> na numer <b><?php echo $offer[$from]['number']; ?></b>. Niżej wpisz otrzymany kod oraz swój nick.
						<br>
						Kod: <input type="text" name="check" size="10" maxlength="8">
						Nick: <input type="text" name="nick" size="10" maxlength="20"> 
						<input type="hidden" name="offer" value="<?php echo $offer[$from]['offer_type']; ?>">
						<input type="hidden" name="numer" value="<?php echo $from; ?>">
						<input type="submit" name="submit" onclick="return confirm('UWAGA! Upewnij się, że postać jest zalogowana. Inaczej mogą być problemy z przyjściem przedmiotów!')" value="Kup !"/>
						<br>
						<?php
							if(isset($offer[$from]['opis'])) echo'<div style="width:15%; padding: 15px; border:1px solid #ababab; margin: 0px auto;">'.$offer[$from]['opis'].'</div>';
						?>
				</form>
						<br>
						<br>Serwis SMS obsługiwany przez: <a href="http://dotpay.pl" target="_blank">Dotpay.pl</a><br>
						Reklamacje składamy tutaj: <a href="http://dotpay.pl/reklamacje/" target="_blank">Dotpay.pl/</a><br>
						Usługa dostepna w sieciach: Orange, Plus GSM, T-Mobile, Play.<br>
						<b>Właściciel serwiu: <?php echo $wlasciciel; ?></b>
					</center>
				<div style="float:left;"><a href="http://www.dotpay.pl/index.php?content=113&newlang=pl" target="_blank">Regulamin</a></div>
				<div style="float:right;"><a href="<?php echo $current; ?>"><img src="http://www.hbmwd.com/site_media/back%20button.png"></a></div><br><br><br>
			</div>
		<!--↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑-->
		<?php
		}
	}
}

$x = $_SERVER['HTTP_USER_AGENT']; 
if(substr_count($x,"pera")!=0) 
   { $opera = "Opera"; } 
else if(substr_count($x,"MSIE")!=0) 
   { $ie = "Internet Explorer"; } 
else if(substr_count($x,"etscape6")!=0) 
   { $netscape = "Netscape 6"; } 
else if(substr_count($x,"Chrome")!=0) 
   { $chrome = "Chrome"; }    
else if(substr_count($x,"Firefox")!=0) 
   { $mozilla = "Mozilla 1.x"; } 
else if(substr_count($x,"4.7")!=0) 
   { $scape = "Netscape 4.7x"; } 
else 
   { $br = "inna"; } 
   
if($_GET['buy'] == "" && $erno == 0)
{
	$from = "1";
	$to = count($offer);
	echo'<table>';
	$n = 0;
	$tr = false;
	while($from < $to)
	{	
	//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓kawałek kodu odpowiedzialny za wyświetlanie usług↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
		if(!($n%3) AND !$tr) 
		{
			echo '<tr>';
			$tr = true;
		}
		echo'<td><form method="post" action="'.$_SERVER['REQUEST_URI'].$zn.'buy=item'.$from.'">';
		if($chrome) echo'<input type="image" name="item'.$from.'" src="'.$offer[$from]['image'].'" value="Wybierz">';
		else echo'<input type="submit" name="item'.$from.'" style="width: 210px; height:138px; display: block; background: url('.$offer[$from]['image'].') no-repeat;" value="">';
		echo '</form></td>';
		$n++;
		if(!($n%3) AND $tr)
		{
			echo '</tr>';
			$tr = false;
		}
	//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑	
		$from++;
	}
	echo'</table>';
}
?>  